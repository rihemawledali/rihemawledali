export { FacturesPage } from './FacturesPage';
