export { PaiementsPage } from './PaiementsPage';
