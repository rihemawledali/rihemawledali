export { HistoriquePage } from './HistoriquePage';
