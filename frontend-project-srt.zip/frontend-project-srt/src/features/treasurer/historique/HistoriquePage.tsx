import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { PageHeader } from '../../../shared/layout/PageHeader';
import { DataTable, type Column } from '../../../shared/data/DataTable';
import { Pagination } from '../../../shared/data/Pagination';
import { SearchInput } from '../../../shared/data/SearchInput';
import { FilterBar, SelectFilter } from '../../../shared/data/FilterBar';
import { StatusBadge } from '../../../shared/data/StatusBadge';
import { historiqueApi } from './api';
import { formatCurrency, formatDateTime } from '../../../shared/lib/formatters';
import type { HistoriqueFinanciere } from '../../../shared/types/domain';
import '../../../shared/layout/CrudPage.css';

const TYPE_LABEL: Record<string, string> = {
  credit: 'Crédit', debit: 'Débit', pret: 'Prêt',
  remboursement: 'Remboursement', cotisation: 'Cotisation',
  indemnite: 'Indemnité', facture: 'Facture',
  entree: 'Entrée', sortie: 'Sortie',
};

export function HistoriquePage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const query = useQuery({
    queryKey: ['historique', { page, search, type, sortBy, sortDir }],
    queryFn: () => historiqueApi.list({ page, size: 15, search, sortBy, sortDir, filters: { type } }),
  });

  const onSort = (k: string) => sortBy === k ? setSortDir(sortDir === 'asc' ? 'desc' : 'asc') : (setSortBy(k), setSortDir('asc'));

  const columns: Column<HistoriqueFinanciere>[] = [
    { key: 'date', header: 'Date', sortable: true, cell: (h) => <span className="cell-muted">{formatDateTime(h.date)}</span> },
    { key: 'reference', header: 'Référence', cell: (h) => <span className="cell-mono">{h.reference}</span> },
    { key: 'description', header: 'Opération', sortable: true, cell: (h) => (
      <div className="row-stack">
        <strong className="cell-strong">{h.description}</strong>
        {h.utilisateur && <span>par {h.utilisateur}</span>}
      </div>
    )},
    { key: 'compteBancaireBanque', header: 'Compte', cell: (h) => h.compteBancaireBanque ? <span className="cell-muted">{h.compteBancaireBanque}</span> : null, width: '140px' },
    { key: 'type', header: 'Type', sortable: true, cell: (h) => <StatusBadge tone="neutral" status={h.type} label={TYPE_LABEL[h.type]} /> },
    { key: 'montant', header: 'Montant', sortable: true, align: 'right', cell: (h) => {
      const positive = h.montant >= 0;
      return (
        <span className={`amount amount-inline ${positive ? 'amount--positive' : 'amount--negative'}`}>
          {positive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {positive ? '+' : '−'}{formatCurrency(Math.abs(h.montant))}
        </span>
      );
    }},
  ];

  function changeSearch(value: string) {
    setSearch(value);
    setPage(1);
  }

  function changeType(value: string) {
    setType(value);
    setPage(1);
  }

  return (
    <div>
      <PageHeader
        title="Historique financier"
        description="Journal complet des opérations financières du système"
        breadcrumb={['Administration', 'Finance', 'Historique']}
      />

      <div className="crud-toolbar">
        <FilterBar>
          <SearchInput value={search} onChange={changeSearch} placeholder="Référence, description, utilisateur..." />
          <SelectFilter label="Type" value={type} onChange={changeType}
            options={Object.entries(TYPE_LABEL).map(([value, label]) => ({ value, label }))} />
        </FilterBar>
      </div>

      <DataTable
        columns={columns}
        rows={query.data?.items ?? []}
        loading={query.isLoading}
        rowKey={(h) => h.id}
        sortBy={sortBy} sortDir={sortDir} onSortChange={onSort}
        emptyTitle="Aucune opération"
      />

      {query.data && query.data.total > 0 && (
        <div className="data-table-card data-table-pagination">
          <Pagination page={page} size={15} total={query.data.total} onPageChange={setPage} />
        </div>
      )}
    </div>
  );
}
