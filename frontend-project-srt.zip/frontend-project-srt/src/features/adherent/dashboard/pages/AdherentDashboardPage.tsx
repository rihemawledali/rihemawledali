import { AdherentDashboardTiles } from '../components/AdherentDashboardSections';
import { useAdherentDashboard } from '../hooks';
import './AdherentDashboardPage.css';

export function AdherentDashboardPage() {
  const dashboard = useAdherentDashboard();

  return (
    <div className="adh-dashboard-page">
      <header className="adh-dashboard-header">
        <div>
          <h1 className="adh-dashboard-title">Tableau de bord</h1>
          <p className="adh-dashboard-subtitle">Vue d'ensemble de votre espace adherent</p>
        </div>
      </header>

      <AdherentDashboardTiles
        data={dashboard.data}
        conventionStats={dashboard.conventionStats}
        hasConventionData={dashboard.hasConventionData}
        loading={dashboard.isLoading}
      />
    </div>
  );
}
