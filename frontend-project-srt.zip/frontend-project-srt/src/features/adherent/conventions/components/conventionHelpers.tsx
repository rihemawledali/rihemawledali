/* ============================================
   Convention Helpers — Adherent Portal
   Shared display logic between all conventions pages.
   ============================================ */

import {
  Stethoscope, UtensilsCrossed, Bus, GraduationCap, Film, Store,
} from 'lucide-react';
import type {
  Convention,
  ConventionType,
  ConventionAdherentStatus,
  ConventionDemandeStatut,
} from '../../../../shared/types/domain';

export const CONV_TYPE_LABEL: Record<ConventionType, string> = {
  sante: 'Santé',
  restauration: 'Restauration',
  transport: 'Transport',
  loisir: 'Loisirs',
  commerce: 'Commerce',
  education: 'Éducation',
};

export const CONV_TYPE_ICON: Record<ConventionType, typeof Stethoscope> = {
  sante: Stethoscope,
  restauration: UtensilsCrossed,
  transport: Bus,
  loisir: Film,
  commerce: Store,
  education: GraduationCap,
};

export const CONV_TYPE_TONE: Record<
  ConventionType,
  'primary' | 'success' | 'warning' | 'info' | 'violet' | 'error'
> = {
  sante: 'error',
  restauration: 'warning',
  transport: 'info',
  loisir: 'violet',
  commerce: 'primary',
  education: 'success',
};

export const CONV_TYPE_IMAGE: Record<ConventionType, string> = {
  sante: 'https://images.unsplash.com/photo-1706806595136-5afefb45da1a?auto=format&fit=crop&w=1200&q=80',
  restauration: 'https://images.unsplash.com/photo-1737140790906-14518fa29d1c?auto=format&fit=crop&w=1200&q=80',
  transport: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80',
  loisir: 'https://images.unsplash.com/photo-1549361360-04d48152048e?auto=format&fit=crop&w=1200&q=80',
  commerce: 'https://images.unsplash.com/photo-1766871138969-510e404f1293?auto=format&fit=crop&w=1200&q=80',
  education: 'https://images.unsplash.com/photo-1669348849154-25e23e2ccf05?auto=format&fit=crop&w=1200&q=80',
};

export function getConventionImageUrl(convention: Pick<Convention, 'imageUrl' | 'type'>): string {
  return convention.imageUrl?.trim() || CONV_TYPE_IMAGE[convention.type];
}

// ----- Adherent-facing convention status -----

export const ADHERENT_STATUS_LABEL: Record<ConventionAdherentStatus, string> = {
  disponible: 'Disponible',
  deja_demandee: 'Déjà demandée',
  active: 'Active',
  expiree: 'Expirée',
  non_disponible: 'Non disponible',
};

/**
 * Visual variant for the adherent-status badge.
 * Maps directly to the colors referenced in the spec.
 */
export const ADHERENT_STATUS_VARIANT: Record<
  ConventionAdherentStatus,
  'success' | 'warning' | 'info' | 'neutral' | 'error'
> = {
  disponible: 'success',
  deja_demandee: 'warning',
  active: 'info',
  expiree: 'neutral',
  non_disponible: 'error',
};

// ----- Demande status (en_attente / validee / refusee / annulee) -----

export const DEMANDE_STATUS_LABEL: Record<ConventionDemandeStatut, string> = {
  en_attente: 'En attente',
  validee: 'Validée',
  refusee: 'Refusée',
  annulee: 'Annulée',
  SOUMISE: 'Soumise',
  APPROUVEE: 'Approuvée',
  EN_COURS: 'En cours',
  JUSTIFIEE: 'Justifiée',
  VALIDEE: 'Validée',
  FACTUREE: 'Facturée',
  PAYEE: 'Payée',
  REFUSEE: 'Refusée',
  ANNULEE: 'Annulée',
};

export const DEMANDE_STATUS_VARIANT: Record<
  ConventionDemandeStatut,
  'success' | 'warning' | 'info' | 'neutral' | 'error'
> = {
  en_attente: 'warning',
  validee: 'success',
  refusee: 'error',
  annulee: 'neutral',
  SOUMISE: 'warning',
  APPROUVEE: 'success',
  EN_COURS: 'info',
  JUSTIFIEE: 'info',
  VALIDEE: 'success',
  FACTUREE: 'info',
  PAYEE: 'success',
  REFUSEE: 'error',
  ANNULEE: 'neutral',
};
